package com.cognizant.truyum.dao;

import java.util.Date;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import java.time.LocalDate;

import java.util.ArrayList;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.coginzant.truyum.util.DateUtil;
import com.cognizant.truyum.model.*;

public class MenuItemDaoImpl implements MenuItemDao {
    Connection con;
    ResultSet rs;
    @Override
    public List<MenuItem> getMenuItemListAdmin() {
         MenuItem menu;
         List<MenuItem> li=new ArrayList<MenuItem>();
         con=ConnectionHandler.getConnection();
         if(con!=null) {
            System.out.println("Connection established");
         }
         try {
             PreparedStatement pre=con.prepareStatement("select * from menu_item");
             rs=pre.executeQuery();          
             while(rs.next()) {
                  System.out.println("User id:");
                  System.out.println(rs.getLong(1));
                  menu=new MenuItem();
                  menu.setId(rs.getLong(1));
                  menu.setName(rs.getString(2));
                  menu.setPrice(rs.getFloat(3));
                  menu.setActive(rs.getBoolean(4));
                  menu.setDateOfLaunch(rs.getDate(5));
                  menu.setCategory(rs.getString(6));
                  menu.setFreeDelivery(rs.getBoolean(7));
                  li.add(menu);
             }

         } catch (SQLException e) {
             System.out.println(e);
         }   
         return li;
    }



    @Override
    public List<MenuItem> getMenuItemListCustomer() {
         MenuItem menu;
         List<MenuItem> li=new ArrayList<MenuItem>();
         con=ConnectionHandler.getConnection();
         if(con!=null)
         System.out.println("Connection established");
         try {
             PreparedStatement pre=con.prepareStatement("select * from menu_item where active='true' and dateOfLaunch<now()");
             rs=pre.executeQuery();          
             while(rs.next()) {
                  menu=new MenuItem();
                  menu.setId(rs.getLong(1));
                  menu.setName(rs.getString(2));
                  menu.setPrice(rs.getFloat(3));
                  menu.setActive(rs.getBoolean(4));
                  menu.setDateOfLaunch(rs.getDate(5));
                  menu.setCategory(rs.getString(6));
                  menu.setFreeDelivery(rs.getBoolean(7));
                  li.add(menu);
             }
         } catch (SQLException e) {
             System.out.println(e);
         }   
         return li;
    }
    @Override
    public void modifyMenuItem(MenuItem menuitem) {
         con=ConnectionHandler.getConnection();
         System.out.println("Connection established");
         try {
             PreparedStatement pre=con.prepareStatement("update menu_item set price=133 where userId=?");
             System.out.println(menuitem.getId());
             pre.setLong(1,menuitem.getId());
             pre.executeUpdate();            
             System.out.println("Updated successfully");
         } catch (SQLException e) {
             System.out.println(e);
         }
    }

    @Override
    public MenuItem getMenuItem(long menuItemId) {
         MenuItem menu = null;
         List<MenuItem> li=new ArrayList<MenuItem>();
         con=ConnectionHandler.getConnection();
         System.out.println("Connection established");
         try {
             PreparedStatement pre=con.prepareStatement("select * from menu_item where userId=?");
             pre.setLong(1, menuItemId);
             rs=pre.executeQuery();
             while(rs.next()) {
                  System.out.println(rs.getLong(1));
                  menu=new MenuItem();
                  menu.setId(rs.getLong(1));
                  menu.setName(rs.getString(2));
                  menu.setPrice(rs.getFloat(3));
                  menu.setActive(rs.getBoolean(4));
                  menu.setDateOfLaunch(rs.getDate(5));
                  menu.setCategory(rs.getString(6));
                  menu.setFreeDelivery(rs.getBoolean(7));
             }
         } catch (SQLException e) {
             System.out.println(e);
         }   
         return menu;
    }
}
