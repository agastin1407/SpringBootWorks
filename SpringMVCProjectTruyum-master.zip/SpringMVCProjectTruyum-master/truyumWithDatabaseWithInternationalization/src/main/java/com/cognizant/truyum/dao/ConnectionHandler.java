package com.cognizant.truyum.dao;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class ConnectionHandler {
     private static Connection con=null;
     public static Properties props=new Properties();
     public static Connection getConnection() {
          try {
              FileInputStream fp=new FileInputStream("C:\\Users\\Viola\\Desktop\\connection.properties");
              props.load(fp);
              Class.forName(props.getProperty("DB_DRIVER_CLASS"));
               con=DriverManager.getConnection(props.getProperty("DB_URL"),props.getProperty("DB_USERNAME"),props.getProperty("DB_PASSWORD"));
               System.out.println("conn established");
          } catch (FileNotFoundException e) {
              System.out.println(e);
          } catch (IOException e) {
              System.out.println(e);
          } catch (ClassNotFoundException e) {
              System.out.println(e);
          } catch (SQLException e) {
              System.out.println(e);
          }
          return con;           
     }
}
