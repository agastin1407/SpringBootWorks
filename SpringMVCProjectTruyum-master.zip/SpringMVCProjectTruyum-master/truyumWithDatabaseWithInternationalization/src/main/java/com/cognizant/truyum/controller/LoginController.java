package com.cognizant.truyum.controller;

import java.security.Principal;
import java.text.ParseException;

import org.omg.CORBA.SystemException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cognizant.truyum.service.LoginService;
import com.cognizant.truyum.service.MenuItemService;

@Controller
public class LoginController {
	@Autowired
	LoginService loginService;
	@Autowired
	MenuItemService menuItemService;
	int user_id;
	int admin_id;
	@GetMapping("/")
	public String indexPage() {
		return "index";
	}
	
	@GetMapping("/LoginCustomer")
	public String signupPageCustomer(ModelMap model) {

		return "LoginCustomer";
	}
	
	@GetMapping("/LoginAdmin")
	public String signupPageAdmin() {
		return "LoginAdmin";
	}
	
	@PostMapping(value = "/logout-admin")
	public String logoutAdmin(ModelMap map) {
	map.addAttribute("logout", "logout succesfull");
	  return "LoginAdmin";
	}
	
	@PostMapping(value = "/logout-customer")
	public String logoutCustomer(ModelMap map) {
	map.addAttribute("logout", "logout succesfull");
	  return "LoginCustomer";
	}
	
	@GetMapping("/success")
	public String successCustomer(ModelMap model,@RequestParam("name")String name,@RequestParam("email")String email,@RequestParam("pswd")String pswd){
		model.addAttribute(name,name);
		loginService.registerService(name,email,pswd);
		return "successCustomer";
	}
	@GetMapping("/login")
	public String loginPage(ModelMap model,@RequestParam(value="email",required=false)String email, @RequestParam(value="password",required=false)String pswd){
		model.addAttribute("email", email);
		if(email.equalsIgnoreCase("")||pswd.equalsIgnoreCase("")){
			model.addAttribute("msg","User name or password cannot be empty");
			return "LoginCustomer";
		}
		user_id=loginService.getId(email, pswd);
		System.out.println("check here"+user_id);
		if(user_id==0){
			model.addAttribute("msg","Sign up to enter");
			return "LoginCustomer";
		}
		try{
			System.out.println("MenuItemListCutomer is being fetched1");
			model.addAttribute("menuItem", menuItemService.getMenuItemListCustomer());
		} catch (ParseException e) {
			e.printStackTrace();
		}
		model.addAttribute("userId",user_id);
		return "menu-item-list-customer";
	}
	@GetMapping("/admin")
	public String loginPageAdmin(ModelMap model,@RequestParam(value="email",required=false)String email, @RequestParam(value="password",required=false)String pswd){
		if(email.equalsIgnoreCase("")||pswd.equalsIgnoreCase("")){
			model.addAttribute("msg","User name or password cannot be empty");
			return "LoginAdmin";
		}
		admin_id=loginService.getId(email, pswd);
		if(admin_id==0){
			model.addAttribute("msg","Sign up to enter");
			return "LoginAdmin";
		}
		try{
			System.out.println("MenuItemListAdmin is being fetched1");
		model.addAttribute("menuItem", menuItemService.getMenuItemListAdmin());
		} catch (ParseException e) {
			e.printStackTrace();
		}
		model.addAttribute("userId",user_id);
		return "menu-item-list-admin";
	}

}
