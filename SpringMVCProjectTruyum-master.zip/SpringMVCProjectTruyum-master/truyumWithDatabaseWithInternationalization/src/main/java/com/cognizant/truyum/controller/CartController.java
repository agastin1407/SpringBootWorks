package com.cognizant.truyum.controller;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.omg.CORBA.SystemException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cognizant.truyum.dao.CartEmptyException;
import com.cognizant.truyum.model.MenuItem;
import com.cognizant.truyum.service.CartService;
import com.cognizant.truyum.service.LoginService;
import com.cognizant.truyum.service.MenuItemService;

@Controller
public class CartController {
	@Autowired
		CartService cartService;
	@Autowired
	MenuItemService menuItemService;
	@Autowired
	LoginService loginService;
	public int user_id=0;
	private static final Logger LOGGER = LoggerFactory.getLogger(MenuItemController.class);

	
	@GetMapping("/add-to-cart")
	public String addToCart(ModelMap model ,@RequestParam("id")int id){
		LOGGER.info("start");
		model.addAttribute("addCartStatus",true);
		try {
			model.addAttribute("menuItem", menuItemService.getMenuItemListCustomer());
		} catch (ParseException e) {
			e.printStackTrace();
		}
		user_id=loginService.getCurrentUser();
		System.out.println("user id"+user_id);
		model.addAttribute("userId",user_id);
		
		cartService.addCartItemService(user_id,id);
		return "menu-item-list-customer";
	}
	@GetMapping("/menu-item-list-customer")
	public String showMenuItem(ModelMap model){
		LOGGER.info("start");
		try{
			System.out.println("MenuItemListCutomer is being fetched1");
		model.addAttribute("menuItem", menuItemService.getMenuItemListCustomer());
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return "menu-item-list-customer";
	}
	
	@GetMapping("/show-cart")
	public String showCart(@RequestParam("userId")int uid ,ModelMap model){
		List<MenuItem> lis=new ArrayList<>();
		model.addAttribute("userId",user_id);
		System.out.println(uid);
		try {
			lis=cartService.getAllCartItemService(uid);
		}catch (CartEmptyException e) {
			return "cart-empty";
		} 
		System.out.println("hai");
		for (MenuItem menuItem : lis) {
			System.out.println(menuItem);
		}
		model.addAttribute("cartItems",lis);
		return "cart";	
	}
	
	@GetMapping("/remove-cart-item")
	public String removeCart(@RequestParam("menuItemId")int mid ,ModelMap model) throws CartEmptyException{
		System.out.println(mid);
		model.addAttribute("remove",mid);
		List<MenuItem> lis=new ArrayList<>();
		model.addAttribute("userId",user_id);
		try{
		lis=cartService.getAllCartItemService(user_id);
		cartService.removeCartItemService(user_id,mid);
		}catch(NullPointerException e){
			return "cart-empty";
		}catch(CartEmptyException e){
			return "cart-empty";
		}
		model.addAttribute("cartItems",lis);
		return "cart";	
	}
}
