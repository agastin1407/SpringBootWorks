package com.cognizant.truyum.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Service;

import com.coginzant.truyum.JDBCTemplate.CartJDBCTemplate;
import com.cognizant.truyum.dao.CartEmptyException;
import com.cognizant.truyum.model.MenuItem;


@Service
public class CartService {
	ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");

   CartJDBCTemplate cartJDBCTemplate = (CartJDBCTemplate)
       context.getBean("cartJDBCTemplate");
    
	public  void addCartItemService(int userid,int id) {
		cartJDBCTemplate.addCartItem(userid, id);
		System.out.println("added to cart successfully");
	}
	
	public List<MenuItem> getAllCartItemService(int userId) throws CartEmptyException{
		return cartJDBCTemplate.getAllCartItems(userId);
	}
	
	public void removeCartItemService(int userid,int menuItemId){
		cartJDBCTemplate.removeCartItem(userid,menuItemId);
	}
}
