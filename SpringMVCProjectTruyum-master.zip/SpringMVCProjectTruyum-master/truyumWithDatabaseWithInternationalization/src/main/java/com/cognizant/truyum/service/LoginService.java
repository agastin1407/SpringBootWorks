package com.cognizant.truyum.service;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Service;

import com.coginzant.truyum.JDBCTemplate.LoginJDBCTemplate;

@Service
public class LoginService {
	ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");
	  LoginJDBCTemplate loginJDBCTemplate = (LoginJDBCTemplate)
   	       context.getBean("loginJDBCTemplate");
	  
	  public int getId(String email, String pswd){
			System.out.println("userid is being fetched2");
			System.out.println(pswd);
			System.out.println(loginJDBCTemplate.getId(email, pswd));
			int admin_id=loginJDBCTemplate.getId(email, pswd);
			return admin_id;
		}
		public void registerService(String name,String email, String pswd){
		 loginJDBCTemplate.registerService(name,email,pswd);
		 }
		public int getCurrentUser(){
			int uid=loginJDBCTemplate.getCurrentUser();
			return uid;
		}
}
