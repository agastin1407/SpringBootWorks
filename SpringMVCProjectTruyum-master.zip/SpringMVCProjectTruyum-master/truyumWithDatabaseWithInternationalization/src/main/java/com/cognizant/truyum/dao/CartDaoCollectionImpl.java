package com.cognizant.truyum.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cognizant.truyum.model.Cart;

import com.cognizant.truyum.model.MenuItem;

public class CartDaoCollectionImpl implements CartDao {
    Connection con;
    ResultSet rs;
    @Override
    public void addCartItem(long userId, long menuItemId) {
                    con=ConnectionHandler.getConnection();
                    PreparedStatement pre;
                    try {
                                    pre = con.prepareStatement("insert into cart values(?,?)");
                                    pre.setLong(1, userId);
                                    pre.setLong(2,menuItemId);
                                    pre.executeUpdate();
                    } catch (SQLException e) {
                                    System.out.println(e);
                    }
    }

    @Override
    public List<MenuItem> getAllCartItems(long userId) throws CartEmptyException {
                    con=ConnectionHandler.getConnection();
                    Cart cart=new Cart();
                    MenuItem menu;
                    int sum=0;
                    List<MenuItem> li=new ArrayList<MenuItem>();
                    try {
                                    System.out.println("join");
                                    PreparedStatement pre=con.prepareStatement("select * from menu_item as m join cart as c on m.userId=c.userId where c.userId=?");
                                    pre.setLong(1, userId);
                                    rs=pre.executeQuery();                                
                                    while(rs.next()) {
                                                    menu=new MenuItem();
                                                    menu.setId(rs.getLong(1));
                                                    menu.setName(rs.getString(2));
                                                    menu.setPrice(rs.getFloat(3));
                                                    menu.setActive(rs.getBoolean(4));
                                                    menu.setDateOfLaunch(rs.getDate(5));
                                                    menu.setCategory(rs.getString(6));
                                                    menu.setFreeDelivery(rs.getBoolean(7));
                                                    li.add(menu);
                                    }
                    } catch (SQLException e) {
                                    System.out.println(e);
                    }
                    try {
                                    System.out.println("With price");
                                    PreparedStatement pre=con.prepareStatement("select sum(price) as total from menu_item as m join cart as c on m.userId=c.userId group by m.userId");
                                    rs=pre.executeQuery();                                
                                    while(rs.next()) {
                                                    sum+=rs.getFloat(1);
                                    }
                                    cart.setTotal(sum);
                    } catch (SQLException e) {
                                    System.out.println(e);
                    }
                    return li;
    }

    @Override
    public void removeCartItem(long userId, long menuItemId) {
                    con=ConnectionHandler.getConnection();
                    PreparedStatement pre;
                    try {
                                    pre = con.prepareStatement("delete from cart where userId=? and menuId=?");
                                    pre.setLong(1, userId);
                                    pre.setLong(2, menuItemId);
                                    pre.executeUpdate();
                    } catch (SQLException e) {
                                    System.out.println(e);
                    }
    }


}