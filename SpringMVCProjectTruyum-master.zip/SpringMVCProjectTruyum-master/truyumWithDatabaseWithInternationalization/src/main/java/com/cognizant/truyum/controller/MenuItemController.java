package com.cognizant.truyum.controller;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.validation.Valid;

import org.omg.CORBA.SystemException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.coginzant.truyum.util.DateUtil;
import com.cognizant.truyum.model.MenuItem;
import com.cognizant.truyum.service.CartService;
import com.cognizant.truyum.service.MenuItemService;

@Controller
public class MenuItemController {
	@Autowired
	MenuItemService menuItemService;
	@Autowired
	CartService cartService;
	int store_id;
	int admin_id;
	private static final Logger LOGGER = LoggerFactory.getLogger(MenuItemController.class);

	@GetMapping("/menu-item-list-admin")
	public String showMenuItemListAdmin(ModelMap model) throws SystemException {
		LOGGER.info("start");
		try {
			model.addAttribute("menuItem", menuItemService.getMenuItemListAdmin());
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return "menu-item-list-admin";
	}

	@GetMapping("/show-edit-menu-item")
	public String showEditMenuItem(@RequestParam("menuItemId") int id, ModelMap model,
			@ModelAttribute("hai") MenuItem menuItem) {
		LOGGER.info("start");
		model.addAttribute("menuItemObj", menuItemService.getMenuItem(id));
		store_id=id;
		return "edit-menu-item";
	}
	
	@RequestMapping(value = "/edit-menu-item1",method=RequestMethod.GET)
	public String editMenuItem(@Valid @ModelAttribute("hai")MenuItem menuItem, BindingResult bindingResult) {
		MenuItem m = menuItem;
		m.setId(store_id);
		System.out.println("Edit menu id updation"+ m.getId());
		System.out.println("Edit menu id updation"+ m.getName());
		if (bindingResult.hasErrors()) {
			return "edit-menu-item";
		} else {
			menuItemService.modifyMenuItem(m);
			return "edit-menu-item-status";
		}
	}
	
}
