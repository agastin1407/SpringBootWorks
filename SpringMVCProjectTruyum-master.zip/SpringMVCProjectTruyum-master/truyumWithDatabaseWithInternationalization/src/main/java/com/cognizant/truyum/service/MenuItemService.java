package com.cognizant.truyum.service;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Service;
import com.coginzant.truyum.JDBCTemplate.MenuItemJDBCTemplate;
import com.cognizant.truyum.model.MenuItem;
@Service
public class MenuItemService {
	ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");

    MenuItemJDBCTemplate menuItemJDBCTemplate = (MenuItemJDBCTemplate)
       context.getBean("menuItemJDBCTemplate");
    
	
	 public List<MenuItem> getMenuItemListAdmin() throws ParseException {
		 List<MenuItem> res= new ArrayList<MenuItem>();
		res= menuItemJDBCTemplate.getMenuItemListAdmin();
    	return res;
    }
	 public List<MenuItem> getMenuItemListCustomer() throws ParseException {
		 List<MenuItem> res = new ArrayList<MenuItem>();
		 System.out.println("MenuItemListCutomer is being fetched2");
		 res=menuItemJDBCTemplate.getMenuItemListCustomer();
		 for(MenuItem p : res)
	            System.out.println(p);
	    	return res;
	    }
	 public MenuItem getMenuItem(int id){	 
		 return menuItemJDBCTemplate.getMenuItem(id);
	 }
	 public void modifyMenuItem(MenuItem m){	 
		menuItemJDBCTemplate.modifyMenuItem(m);
	 }
}
