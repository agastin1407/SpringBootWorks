package com.coginzant.truyum.JDBCTemplate;

import java.util.Date;
import java.util.List;
import javax.sql.DataSource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.coginzant.truyum.RowMapper.menuItemMapper;
import com.cognizant.truyum.dao.MenuItemDao;
import com.cognizant.truyum.model.MenuItem;

@Component
public class MenuItemJDBCTemplate  implements MenuItemDao {
   private DataSource dataSource;
   private JdbcTemplate jdbcTemplateObject;
   
   public void setDataSource(DataSource dataSource) {
      this.dataSource = dataSource;
      this.jdbcTemplateObject = new JdbcTemplate(dataSource);
   }
 
@Override
public List<MenuItem> getMenuItemListAdmin() {
	String SQL = "select * from menuitem";
    List <MenuItem> menuItemList = jdbcTemplateObject.query(SQL, new menuItemMapper());
    return menuItemList;
}
@Override
public List<MenuItem> getMenuItemListCustomer() {
	System.out.println("MenuItemListCutomer is being fetched3");
	String SQL = "select * from menuitem where active='1'";
    List <MenuItem> menuItemList = jdbcTemplateObject.query(SQL, new menuItemMapper());
    return menuItemList;
}
@Override
public void modifyMenuItem(MenuItem menuitem) {
	String SQL = "update menuitem set name=?,price=?,active=?,dateOfLaunch=?,category=?,freeDelivery=?  where id=?";
	long id=menuitem.getId();
	String name=menuitem.getName();
	float price= menuitem.getPrice();
	boolean active=menuitem.isActive();
	Date date=menuitem.getDateOfLaunch();
	String category=menuitem.getCategory();
	boolean freeDelivery=menuitem.isFreeDelivery();
    jdbcTemplateObject.update(SQL, name,price,active,date,category,freeDelivery, id);
    System.out.println("Updated Record with ID = " + id );
}
@Override
public MenuItem getMenuItem(long menuItemId) {
	String SQL = "select * from menuitem where id=?";
    MenuItem menuItem = jdbcTemplateObject.queryForObject(SQL,new Object[]{menuItemId}, new menuItemMapper());
    return menuItem;
}
public int getAdminId(String email, String pswd) {
	int uid;
	int is_present;
	System.out.println("userid is being fetched3");

	String SQL = "select exists(select uid from admin where email=? and pswd=?)";
    is_present=jdbcTemplateObject.queryForObject(SQL, new Object[]{email,pswd},Integer.class);
    if(is_present==1){
    	String SQL1 = "select uid from admin where email=? and pswd=?";
        uid=jdbcTemplateObject.queryForObject(SQL1, new Object[]{email,pswd},Integer.class);
    }else{
    	return 0;
    }
    System.out.println("email returened"+email+pswd);

    System.out.println("uid returened"+uid);

	return uid;
}

public void registerService(String name, String email, String pswd) {
	String SQL = "insert into admin(name,email,pswd) values (?, ?,?)";
	 jdbcTemplateObject.update( SQL, name,email,pswd );
	return;
}
}