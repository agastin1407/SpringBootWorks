package com.coginzant.truyum.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

	public class DateUtil {
		public static Date convertToDate(String dateToBeConverted)
				throws ParseException {
			SimpleDateFormat formatter1=new SimpleDateFormat("dd/MM/yyyy");  
			Date d=formatter1.parse(dateToBeConverted);
			return d;
		}

}

