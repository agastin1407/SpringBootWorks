package com.coginzant.truyum.JDBCTemplate;


import java.util.List;
import javax.sql.DataSource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.coginzant.truyum.RowMapper.menuItemMapper;
import com.cognizant.truyum.dao.CartDao;
import com.cognizant.truyum.dao.CartEmptyException;
import com.cognizant.truyum.dao.MenuItemDao;
import com.cognizant.truyum.model.MenuItem;

@Component
public class CartJDBCTemplate  implements CartDao {
   private DataSource dataSource;
   private JdbcTemplate jdbcTemplateObject;
   
   public void setDataSource(DataSource dataSource) {
      this.dataSource = dataSource;
      this.jdbcTemplateObject = new JdbcTemplate(dataSource);
   }
   
@Override
public void addCartItem(long userId, long menuItemId) {
	 String SQL = "insert into cart values (?, ?)";
	 jdbcTemplateObject.update( SQL, userId, menuItemId);
	 System.out.println("Created Record Name = "+userId+" "+menuItemId);
}
@Override
public List<MenuItem> getAllCartItems(long userId) throws CartEmptyException {
	System.out.println(userId);
	String SQL = "select * from menuitem as m join cart as c on m.id=c.id where c.uid=?";
    List <MenuItem> menuItemList = jdbcTemplateObject.query(SQL,new Object[]{userId}, new menuItemMapper());
    System.out.println("Hey there");
    for (MenuItem menuItem : menuItemList) {
		System.out.println(menuItem);
	}
    if(menuItemList.isEmpty()){
    	throw new CartEmptyException();
    }
    String SQL1 = "select sum(price) as total from menuitem as m join cart as c on m.id=c.id where c.uid=?";
    float result= jdbcTemplateObject.queryForObject(SQL1,new Object[]{userId}, Float.class);
    System.out.println("total sum is "+ result);
    return menuItemList;
}
@Override
public void removeCartItem(long userId, long menuItemId) {
	String SQL = "delete from cart where uid=? and id=?";
    jdbcTemplateObject.update(SQL, userId, menuItemId);
    System.out.println("Deleted Record with ID = " + userId );
    return;
}
}