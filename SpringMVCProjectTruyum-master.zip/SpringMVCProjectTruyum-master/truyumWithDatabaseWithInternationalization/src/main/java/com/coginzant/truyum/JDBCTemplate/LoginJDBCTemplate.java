package com.coginzant.truyum.JDBCTemplate;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;

public class LoginJDBCTemplate {
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplateObject;
	int uid;
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		this.jdbcTemplateObject = new JdbcTemplate(dataSource);
	}

	public int getId(String email, String pswd) {
		
		int is_present;
		System.out.println("userid is being fetched3");
		String SQL = "select exists(select uid from login where email=? and pswd=?)";
		
	    is_present=jdbcTemplateObject.queryForObject(SQL, new Object[]{email,pswd},Integer.class);
	    if(is_present==1){
	    	String SQL1 = "select uid from login where email=? and pswd=?";
	        uid=jdbcTemplateObject.queryForObject(SQL1, new Object[]{email,pswd},Integer.class);
	    }else{
	    	return 0;
	    }
	    System.out.println("email returened"+email+pswd);
	    System.out.println("uid returened"+uid);
		return uid;	
	}

	public int getCurrentUser(){
		return uid;
	}
	public void registerService(String name,String email, String pswd) {
		String SQL = "insert into login(name,email,pswd) values (?, ?,?)";
		jdbcTemplateObject.update(SQL, name,email, pswd);
		return;
	}
	
}
