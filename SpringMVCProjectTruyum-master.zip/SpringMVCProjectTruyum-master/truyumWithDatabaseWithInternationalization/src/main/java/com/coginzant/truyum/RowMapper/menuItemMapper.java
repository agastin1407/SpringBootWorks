package com.coginzant.truyum.RowMapper;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

import com.cognizant.truyum.model.MenuItem;

public class menuItemMapper implements RowMapper<MenuItem> {
   public MenuItem mapRow(ResultSet rs, int rowNum) throws SQLException {
      MenuItem menuItem = new MenuItem();
      menuItem.setId(rs.getInt("id"));
      menuItem.setName(rs.getString("name"));
      menuItem.setPrice(rs.getInt("price"));
      menuItem.setActive(rs.getBoolean("active"));
      menuItem.setDateOfLaunch(rs.getDate("dateOfLaunch"));
      menuItem.setCategory(rs.getString("category"));
      menuItem.setFreeDelivery(rs.getBoolean("freeDelivery"));
      return menuItem;
   }
}