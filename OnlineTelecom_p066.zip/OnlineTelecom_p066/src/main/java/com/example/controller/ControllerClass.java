package com.example.controller;

import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.model.MobileUser;
import com.example.service.ServiceClass;

@Controller
public class ControllerClass {

	MobileUser user;
	@Autowired
	ServiceClass service;
	@Autowired
	private JdbcTemplate jdbcTemp;

	// Controller methods for 1.Create new connection

	@GetMapping("/")
	public String showHomePage() {
		return "homepage";
	}

	@GetMapping("/newConnection")
	public String createNewConnection(@ModelAttribute("user") MobileUser user, Model model) {
		return "newConnection";
	}

	@PostMapping("/newConnection")
	public String createUser(@Valid @ModelAttribute("user") MobileUser user, BindingResult result, Model model) {
		if (result.hasErrors()) {
			return "newConnection";
		}
		service.createUser(user);
		return "success";
	}

	// Controller methods for 2.Pay bill Action

	@GetMapping("/paybill")
	public String chechkMobileNumber() {
		return "checkmobilenumber1";
	}

	@GetMapping("/paybillaction")
	public String validateMobileNumber(ModelMap model, @RequestParam String phoneNumber) {
		List<MobileUser> validate = service.findMobileUser(phoneNumber);
		System.out.println(validate);
		if (validate.isEmpty())
			return "invalidnumber";
		else {
			user = validate.get(0);
			System.out.println(user.getPhoneNumber());
			model.put("balance", user.getBalance());
			return "paybill";
		}
	}

	@GetMapping("/balanceupdation")
	public String balanceUpdation(@RequestParam String amountPay, ModelMap m) {
		System.out.println(amountPay);
		user.setBalance((int) (user.getBalance() + Integer.parseInt(amountPay)));
		System.out.println(user.getBalance());
		service.updateMobileUser(user);
		return "success";
	}

	// Controller methods for 3.Change of Plan

	@GetMapping("/changePlan")
	public String showpnoformmobieplan() {
		return "checkmobilenumber2";
	}

	@GetMapping("/changePlanAction")
	public String channgeMobilePlan(@RequestParam String phoneNumber, ModelMap model) {

		List<MobileUser> uservalidate = service.findMobileUser(phoneNumber);
		if (uservalidate.isEmpty())
			return "invalidnumber";
		else {
			user = uservalidate.get(0);
			model.put("Plan", user.getPlan());
			return "changePlanPage";
		}

	}

	@GetMapping("/submitChangePlan")
	public String changeplan(@RequestParam String plan, ModelMap m) {
		System.out.println(plan);
		user.setPlan(plan);
		service.updatePlan(user);
		return "success";
	}

	// Controller methods for 4.Change of ServiceType

	@GetMapping("/changeService")
	public String pnoforservice() {
		return "checkmobilenumber3";

	}

	@GetMapping("/changeServiceAction")
	public String redirecctTOchanngeService(@RequestParam String phoneNumber, ModelMap model) {
		List<MobileUser> uservalidate = service.findMobileUser(phoneNumber);
		System.out.println(uservalidate);
		if (uservalidate.isEmpty())
			return "invalidnumber";
		else {
			user = uservalidate.get(0);
			System.out.println(user.getPhoneNumber());
			model.put("Service", user.getServiceType());
			return "changeServicePage";
		}
	}

	@GetMapping("/submitChangeService")
	public String changeService(@RequestParam String Service, ModelMap m) {
		System.out.println(Service);
		user.setServiceType(Service);
		service.updateService(user);
		return "success";
	}

	// To display SqlData efficiently ( Cross-verification process )

	@GetMapping("/backenddetails")
	public String showBackEndDetails(ModelMap map) {
		try {
			String query = "select * from MobileUser";
			List<MobileUser> Usersdetails = jdbcTemp.query(query, BeanPropertyRowMapper.newInstance(MobileUser.class));
			map.addAttribute("Usersdetails", Usersdetails);
		} catch (Exception e) {
			System.out.print(e);
		}
		return "sqlDetails";
	}

}
