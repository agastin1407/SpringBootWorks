package com.example.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.stereotype.Service;

import com.example.model.MobileUser;

@Service
public class ServiceClass {
	
	@Autowired
	private JdbcTemplate jdbc;


	public void createUser(@Valid MobileUser user) {

		PreparedStatementCreator ob=new PreparedStatementCreator() {
			
			@Override
			public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
				// TODO Auto-generated method stub
				PreparedStatement query=con.prepareStatement("insert into MobileUser values (?,?,?,?,?,?,?) ");
				query.setString(1, user.getPhoneNumber());
				query.setString(2, user.getFirstName());
				query.setString(3, user.getLastName());
				query.setString(4, user.getAddressDetails());
				query.setString(5, user.getServiceType());
				query.setString(6, user.getPlan());
				query.setInt(7, user.getBalance());
				return query;
			}
		};
		 jdbc.update(ob);
		
	}

	public void updateMobileUser(MobileUser user) {

		jdbc.update("update MobileUser set balance="+user.getBalance()+" where phoneNumber='"+user.getPhoneNumber()+"';");
			
	}

	

	public List<MobileUser> findMobileUser(String phoneNumber) {

		try {
			String query = "select * from MobileUser where phoneNumber='"+phoneNumber+"'; ";
			
			List<MobileUser> UserPhonenumber = jdbc.query(query, BeanPropertyRowMapper.newInstance(MobileUser.class));
			
			return UserPhonenumber;
			
		} catch (Exception e) {
			System.out.print(e);
		}
		return null;
	}

	public void updatePlan(MobileUser user) {

		jdbc.update("update MobileUser set plan='"+user.getPlan()+"' where phoneNumber='"+user.getPhoneNumber()+"';");
		
	}

	public void updateService(MobileUser user) {

		jdbc.update("update MobileUser set serviceType='"+user.getServiceType()+"' where phoneNumber='"+user.getPhoneNumber()+"';");
		
	}

}
