package com.cognizant.truyum.controller;

import java.util.List;
import javax.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.bind.annotation.RestController;
//import org.springframework.web.servlet.ModelAndView;

import com.cognizant.truyum.dao.MenuItemDao;
import com.cognizant.truyum.model.MenuItem;
import com.cognizant.truyum.service.MenuItemService;
@Controller
public class MenuItemController {

	private static final Logger LOGGER = LoggerFactory.getLogger(MenuItemController.class);

	@Autowired
	private MenuItemService menuItemService;

	//@GetMapping("/show-menu-item-list-admin")
	@RequestMapping(value="/show-menu-item-list-admin", method=RequestMethod.GET)
	public String showMenuItemListAdmin(ModelMap model) {
		LOGGER.info("Start");
		@SuppressWarnings("rawtypes")
		List menuItemListAdmin = menuItemService.getMenuItemListAdmin();
		System.out.println(menuItemListAdmin);
		model.addAttribute("getMenuItemListAdmin", menuItemListAdmin);
		LOGGER.info("End");
		//ModelAndView mav= new ModelAndView("menu-item-list-admin");
		return "menu-item-list-admin";
		//return "menu-item-list-admin";
	}

	//@GetMapping("/show-menu-list-customer")
	@RequestMapping(value="/show-menu-item-list-customer", method=RequestMethod.GET)
	public String showMenuItemListCustomer(ModelMap model) {
		LOGGER.info("Start");
		@SuppressWarnings("rawtypes")
		List menuItemListCustomer = menuItemService.getMenuItemListCustomer();
		System.out.println(menuItemListCustomer);
		model.addAttribute("getMenuItemListAdmin", menuItemListCustomer);
		LOGGER.info("End");
		return "menu-item-list-customer";
	}

	//@GetMapping("/show-edit-menu-item")
	@RequestMapping(value="/show-edit-menu-item", method=RequestMethod.GET)
	public String showEditMenuItem(@RequestParam long menuItemId, ModelMap model) {
		LOGGER.info("Start");
		MenuItem menuItem = menuItemService.getMenuItem(menuItemId);
		System.out.println(menuItem);
		model.addAttribute("MenuItem", menuItem);
		LOGGER.info("End");
		return "edit-menu-item";

	}

	@SuppressWarnings("null")
	//@PostMapping("/edit-menu-item")
	@RequestMapping(value="/edit-menu-item", method=RequestMethod.POST)
	public String editMenuItem(@Valid MenuItem menuItem, BindingResult bindingResult) {
		LOGGER.info("Start");
		if (bindingResult.hasErrors()) {
			return "edit-menu-item";
		}
		MenuItemDao menuItemDao = null;
		menuItemDao.modifyMenuItem(menuItem);
		System.out.println(menuItem);
		LOGGER.info("End");
		return "edit-menu-item-status";
	}

}
