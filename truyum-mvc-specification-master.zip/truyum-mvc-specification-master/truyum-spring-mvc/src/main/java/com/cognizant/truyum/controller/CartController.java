package com.cognizant.truyum.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
//import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.bind.annotation.RestController;

import com.cognizant.truyum.dao.CartEmptyException;
import com.cognizant.truyum.service.CartService;

@Controller
public class CartController {

	private static final Logger LOGGER = LoggerFactory.getLogger(MenuItemController.class);

	@Autowired
	private CartService cartService;

	//@GetMapping("/add-to-cart") here i used request mapping and also tested getMappingi.e comment section
	@RequestMapping(value="/add-to-cart", method=RequestMethod.GET)
	public String addToCart(@RequestParam long menuItemId, ModelMap modelMap) {
		LOGGER.info("Start");
		cartService.addToCart(1, menuItemId);
		modelMap.addAttribute("addCartStatus", true);
		LOGGER.info("End");
		return "menu-item-list-customer";
	}

	//@GetMapping("/show-cart")
	@RequestMapping(value="/show-cart", method=RequestMethod.GET)
	public String showCart( ModelMap modelMap) {
		LOGGER.info("Start");
		@SuppressWarnings("rawtypes")
		List cart;
		try {
			cart = cartService.getAllCartItems(1);
			System.out.println(cart);
		} catch (CartEmptyException e) {
			return "cart-empty";
		}
		modelMap.addAttribute("allcartitems", cart);
		LOGGER.info("End");
		return "cart";
	}

	//@GetMapping("/remove-cart")
	@RequestMapping(value="/remove-cart", method=RequestMethod.GET)
	public String removeCart(@RequestParam("menuItemId") long menuItemId, ModelMap modelMap) {
		LOGGER.info("Start");
		@SuppressWarnings({ "rawtypes", "unused" })
		List cart;
		try {
			cartService.removeCartItem(1, menuItemId);
			cart = cartService.getAllCartItems(1);
		} catch (CartEmptyException e) {
			return "cart-empty";
		}
		modelMap.addAttribute("removeCartItemStatus", true);
		LOGGER.info("End");
		return "cart";
	}

}
