package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.model.AdminCredentials;
import com.example.model.ComplaintDetails;
import com.example.model.ComplaintStatus;
import com.example.model.CustomerCredentials;
import com.example.service.ServiceClass;

@Controller
public class ContollerClass {

	@Autowired
	JdbcTemplate jdbcTemplate;

	@Autowired
	ServiceClass serviceClass;

	@GetMapping("/")
	public String navigateToLogin() {
		return "login";
	}

	@GetMapping("/addminRegister")
	public String navigateAdminRegister() {
		return "adminRegister";
	}

	@GetMapping("/customerRegister")
	public String navigateCustomerRegister() {
		return "customerRegister";
	}

	@PostMapping("/adminLogin")
	public String adminLogin(@RequestParam("adEmailId") String email, @RequestParam("adPassword") String password,ModelMap map) {
		String query = "select * from adminLogin where adEmail='" + email + "';";
		AdminCredentials ad = jdbcTemplate.queryForObject(query,
				BeanPropertyRowMapper.newInstance(AdminCredentials.class));
		if (ad.getAdPassword().equalsIgnoreCase(password)) {
			List<ComplaintDetails> cd=serviceClass.getAdminPage();
			map.addAttribute("cd",cd);
			return "AdHomePage";
		} else {
			return "invalidDetails";
		}
	}
	
	@PostMapping("/setStatus")
	public String updateStatus(@ModelAttribute("statusSet")ComplaintStatus cs,ModelMap map) {
		serviceClass.updateStatus(cs);
		List<ComplaintDetails> cd=serviceClass.getAdminPage();
		map.addAttribute("cd",cd);
		return "AdHomePage";}

	@PostMapping("/customerLogin")
	public String customerLogin(@RequestParam("custEmailId") String email,
			@RequestParam("custPassword") String password, ModelMap map) {
		String query = "select * from customerLogin where custEmail='" + email + "';";
		CustomerCredentials cd = jdbcTemplate.queryForObject(query,
				BeanPropertyRowMapper.newInstance(CustomerCredentials.class));
		if (cd.getCustPassword().equalsIgnoreCase(password)) {
			return "CustHomePage";
		} else {
			return "invalidDetails";
		}
	}

	@PostMapping("/addminRegisterAction")
	public String adminRegisterAccount(@ModelAttribute("admin") AdminCredentials ad) {
		serviceClass.createAdminAoount(ad);
		return "login";

	}

	@PostMapping("/customerRegisterAction")
	public String CustomerRegisterAccount(@ModelAttribute("customer") CustomerCredentials cd) {
		serviceClass.createCustomerAoount(cd);
		return "login";

	}

	@PostMapping("/ComplaintAction")
	public String complaintAction(@ModelAttribute("complaint") ComplaintDetails complaint, ModelMap map) {
		try {
			serviceClass.updateComplaint(complaint);
		} catch (Exception error) {
			map.put("error", "Complaint Id Already Exists. Try Again");
			return "CustHomePage";
		}
		return "success";
	}

	@GetMapping("/viewStatus")
	public String customerViewStatus() {
		return "verifycomplaintId";

	}

	@GetMapping("/viewStatusAction")
	public String statusAction(@RequestParam("complaintId") String id, ModelMap map) {
		ComplaintStatus cs = serviceClass.getCustomerStatus(id);
		map.addAttribute("cs", cs);
		return "status";
	}
	

}
