package com.example.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.stereotype.Service;

import com.example.model.AdminCredentials;
import com.example.model.ComplaintDetails;
import com.example.model.ComplaintStatus;
import com.example.model.CustomerCredentials;

@Service
public class ServiceClass {

	@Autowired
	JdbcTemplate jdbcTemplate;

	public void createAdminAoount(AdminCredentials ad) {
		PreparedStatementCreator obj = new PreparedStatementCreator() {

			@Override
			public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
				// TODO Auto-generated method stub
				PreparedStatement sql = con.prepareStatement("insert into adminLogin values (?,?,?) ");
				sql.setString(1, ad.getAdName());
				sql.setString(2, ad.getAdEmail());
				sql.setString(3, ad.getAdPassword());
				return sql;
			}
		};
		jdbcTemplate.update(obj);

	}

	public void createCustomerAoount(CustomerCredentials cd) {
		PreparedStatementCreator obj = new PreparedStatementCreator() {

			@Override
			public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
				// TODO Auto-generated method stub
				PreparedStatement sql = con.prepareStatement("insert into customerLogin values (?,?,?) ");
				sql.setString(1, cd.getCustName());
				sql.setString(2, cd.getCustEmail());
				sql.setString(3, cd.getCustPassword());
				return sql;
			}
		};
		jdbcTemplate.update(obj);

	}

	public void updateComplaint(ComplaintDetails complaint) {
		PreparedStatementCreator obj = new PreparedStatementCreator() {

			@Override
			public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
				// TODO Auto-generated method stub
				PreparedStatement sql = con.prepareStatement("insert into complaint values (?,?,?,?,?,?) ");
				sql.setString(1, complaint.getFirstName());
				sql.setString(2, complaint.getLastName());
				sql.setString(3, complaint.getEmail());
				sql.setString(4, complaint.getPhoneNo());
				sql.setString(5, complaint.getComplaintID());
				sql.setString(6, complaint.getComplaint());
				return sql;
			}
		};
		jdbcTemplate.update(obj);

	}

	public ComplaintStatus getCustomerStatus(String id) {
		String sql="select * from complaintstatus where complaintID='"+id+"';";
		ComplaintStatus cs = jdbcTemplate.queryForObject(sql, BeanPropertyRowMapper.newInstance(ComplaintStatus.class));
		return cs;
	}

	public List<ComplaintDetails> getAdminPage() {
		String sql="select * from complaint;";
		List<ComplaintDetails> cd= jdbcTemplate.query(sql, BeanPropertyRowMapper.newInstance(ComplaintDetails.class));
		return cd;
	}

	public void updateStatus(ComplaintStatus cs) {
		PreparedStatementCreator obj = new PreparedStatementCreator() {

			@Override
			public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
				PreparedStatement sql = con.prepareStatement("insert into complaintstatus values (?,?,?,?,?,?) ");
				sql.setString(1, cs.getComplaintID());
				sql.setString(2, cs.getFirstName());
				sql.setString(3, cs.getEmail());
				sql.setString(4, cs.getComplaint());
				sql.setString(5, cs.getPriority());
				sql.setString(6, cs.getStatus());
				return sql;
			}
		};
		jdbcTemplate.update(obj);
	}
}
