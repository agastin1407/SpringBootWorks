package com.example.model;

public class CustomerCredentials {
	
	private String custName;
	private String custEmail;
	private String custPassword;
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getCustEmail() {
		return custEmail;
	}
	public void setCustEmail(String custEmail) {
		this.custEmail = custEmail;
	}
	public String getCustPassword() {
		return custPassword;
	}
	public void setCustPassword(String custPassword) {
		this.custPassword = custPassword;
	}
	@Override
	public String toString() {
		return "CustomerCredentials [custName=" + custName + ", custEmail=" + custEmail + ", custPassword="
				+ custPassword + "]";
	}
	
	

}
