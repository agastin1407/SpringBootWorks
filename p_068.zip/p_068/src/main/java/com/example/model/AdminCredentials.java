package com.example.model;

public class AdminCredentials {
	
	private String adName;
	private String adEmail;
	private String adPassword;
	public String getAdName() {
		return adName;
	}
	public void setAdName(String adName) {
		this.adName = adName;
	}
	public String getAdEmail() {
		return adEmail;
	}
	public void setAdEmail(String adEmail) {
		this.adEmail = adEmail;
	}
	public String getAdPassword() {
		return adPassword;
	}
	public void setAdPassword(String adPassword) {
		this.adPassword = adPassword;
	}
	@Override
	public String toString() {
		return "AdminCredentials [adName=" + adName + ", adEmail=" + adEmail + ", adPassword=" + adPassword + "]";
	}
	
	

}
