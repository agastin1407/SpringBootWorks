create database p_068;
use p_068;
show tables;
create table adminLogin(
adName varchar(50),
adEmail varchar(50),
adPassword varchar(50)
);
create table customerLogin(
custName varchar(50),
custEmail varchar(50),
custPassword varchar(50)
);
create table complaint(
firstName varchar(50),
lastName varchar(50),
email varchar(50),
phoneNo varchar(12),
complaintID varchar (7),
complaint varchar (1000)
);
create table complaintstatus(
complaintID varchar(10),
firstName varchar(50),
email varchar (50),
complaint varchar(1000),
priority varchar(10),
status varchar(10)
);
select * from adminLogin;
select * from customerLogin;
select * from complaint;
select * from complaintstatus;
delete from complaintstatus;