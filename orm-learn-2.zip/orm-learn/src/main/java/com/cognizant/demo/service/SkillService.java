package com.cognizant.demo.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.demo.Repository.SkillRepository;
import com.cognizant.demo.model.Skill;

@Service
@Transactional
public class SkillService {
	
	@Autowired
	SkillRepository sRepo;
	
	public Skill get(int id) {
		return sRepo.findById(id).get();
	}

	public void save(Skill skill) {
		sRepo.save(skill);
	}
	

}
