package com.cognizant.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cognizant.demo.model.Department;

@Repository
public interface DepartmentRepository extends JpaRepository<Department, Integer>{

}
