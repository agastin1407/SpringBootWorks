package com.cognizant.demo.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.demo.Repository.EmployeeRepository;
import com.cognizant.demo.model.Employee;

@Service
@Transactional
public class EmployeeService {

	@Autowired
	EmployeeRepository eRepo;

	
	public Employee get(int id) {
		return eRepo.findById(id).get();
	}

	public void save(Employee employee) {
		eRepo.save(employee);
	}
	
	

}
