package com.cognizant.demo;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.cognizant.demo.model.Country;
import com.cognizant.demo.model.Department;
import com.cognizant.demo.model.Employee;
import com.cognizant.demo.model.Skill;
import com.cognizant.demo.service.CountryNotFoundException;
import com.cognizant.demo.service.CountryService;
import com.cognizant.demo.service.DepartmentService;
import com.cognizant.demo.service.EmployeeService;
import com.cognizant.demo.service.SkillService;

@SpringBootApplication
public class OrmLearnApplication {

	private static final Logger LOGGER = LoggerFactory.getLogger(OrmLearnApplication.class);
	private static CountryService countryService;
	private static EmployeeService employeeService;
	private static DepartmentService departmentService;
	private static SkillService skillService;

	private static void testGetAllCountries() {
		LOGGER.info("Start Test 1");
		List<Country> countries = countryService.getAllCountries();
		LOGGER.debug("countries={}", countries);
		LOGGER.info("End");
	}

	private static void findCountryByCodeTest() throws CountryNotFoundException {
		LOGGER.info("Start Test 2");
		Country country = countryService.findCountryByCode("IN");
		LOGGER.debug("Country:{}", country);
		LOGGER.info("End");
	}

	private static void addCountryTest() {
		LOGGER.info("Start Test 3");
		Country country = new Country("AG", "Agastin");
		countryService.addCountry(country);
		LOGGER.info("End");
	}

	private static void deleteCountryTest() {
		LOGGER.info("Start Test 4");
		countryService.deleteCountry("ZW");
		LOGGER.info("End");
	}

	private static void updateCountryTest() throws CountryNotFoundException {
		LOGGER.info("Start Test 5");
		countryService.updateCountry("Zambiass", "ZM");
		LOGGER.info("End");
	}

	private static void testGetDepartment() {
		LOGGER.info("Start Test 9");
		Department department = departmentService.get(2);
		LOGGER.debug("Department={}", department);
		LOGGER.info("End");
	}

	private static void testAddSkillToEmployee() {
		LOGGER.info("Start test 10");
		Employee employee = employeeService.get(2);// "get an emp id with no relationship of skill"
		Skill skill = skillService.get(4);
		Set<Skill> s = employee.getSkillList();
		s.add(skill);
		employee.setSkillList(s);
		employeeService.save(employee);
		LOGGER.debug("Employees={}", employee);
		LOGGER.info("End");
	}

	private static void testGetEmployee() {
		LOGGER.info("Start Test 6");
		Employee employee = employeeService.get(1);
		LOGGER.debug("Employee:{}", employee);
		LOGGER.debug("Department:{}", employee.getDepartment());
		LOGGER.debug("Skills:{}", employee.getSkillList());
		LOGGER.info("End");
	}

	private static void addEmployeeTest() throws ParseException {
		LOGGER.info("Start Test 7");
		Department dept = departmentService.get(1);
		SimpleDateFormat ft = new SimpleDateFormat("yyyy-mm-dd");
		String date = "1998-07-14";
		Date d = ft.parse(date);
		Employee emp = new Employee("Agastin", 54000, true, d, dept);
		employeeService.save(emp);
		System.out.println("Details SAVED");
		LOGGER.info("End");
	}

	private static void updateEmployeeTest() {
		LOGGER.info("Start Test 8");
		Department dept = departmentService.get(3);
		Employee emp = employeeService.get(6);
		emp.setDepartment(dept);
		employeeService.save(emp);
		System.out.println("Details UPDATED");
		LOGGER.info("End");
	}

	public static void main(String[] args) throws CountryNotFoundException, ParseException {

		ApplicationContext context = SpringApplication.run(OrmLearnApplication.class, args);
		LOGGER.info("Inside main");
		countryService = context.getBean(CountryService.class);
		employeeService = context.getBean(EmployeeService.class);
		departmentService = context.getBean(DepartmentService.class);
		skillService = context.getBean(SkillService.class);
		testGetAllCountries();
		findCountryByCodeTest();
		addCountryTest();
		updateCountryTest();
		deleteCountryTest();
		testGetEmployee();
		addEmployeeTest();
		updateEmployeeTest();
		testAddSkillToEmployee();
		// testEmployee();
		// testDepartment();
	}
}
