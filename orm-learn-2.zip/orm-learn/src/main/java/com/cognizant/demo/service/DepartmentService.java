package com.cognizant.demo.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.demo.Repository.DepartmentRepository;
import com.cognizant.demo.model.Department;

@Service
@Transactional
public class DepartmentService {

	@Autowired
	DepartmentRepository dRepo;

	public Department get(int id) {
		return dRepo.findById( id).get();
	}

	public void save(Department department) {
		dRepo.save(department);
	}

}
