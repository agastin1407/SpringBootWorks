drop database FarmFresh;
create database FarmFresh;
use FarmFresh;
create table flogin(
fName varchar(50),
fEmailId varchar(50),
fPassword varchar(50)
);
create table clogin(
cName varchar(50),
cEmailId varchar(50),
cPassword varchar(50)
);
select * from flogin;
select * from clogin;