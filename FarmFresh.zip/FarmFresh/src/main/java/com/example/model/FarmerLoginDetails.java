package com.example.model;

public class FarmerLoginDetails {
	private String fName;
	private String fEmailId;
	private String fPassword;

	public String getfName() {
		return fName;
	}

	public void setfName(String fName) {
		this.fName = fName;
	}

	public String getfEmailId() {
		return fEmailId;
	}

	public void setfEmailId(String fEmailId) {
		this.fEmailId = fEmailId;
	}

	public String getfPassword() {
		return fPassword;
	}

	public void setfPassword(String fPassword) {
		this.fPassword = fPassword;
	}

	@Override
	public String toString() {
		return "FarmerLoginDetails [fName=" + fName + ", fEmailId=" + fEmailId + ", fPassword=" + fPassword + "]";
	}

}
