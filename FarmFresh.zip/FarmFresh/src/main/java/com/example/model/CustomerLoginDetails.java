package com.example.model;

public class CustomerLoginDetails {
	private String cName;
	private String cEmailId;
	private String cPassword;

	@Override
	public String toString() {
		return "CustomerLoginDetails [cName=" + cName + ", cEmailId=" + cEmailId + ", cPassword=" + cPassword + "]";
	}

	public String getcName() {
		return cName;
	}

	public void setcName(String cName) {
		this.cName = cName;
	}

	public String getcEmailId() {
		return cEmailId;
	}

	public void setcEmailId(String cEmailId) {
		this.cEmailId = cEmailId;
	}

	public String getcPassword() {
		return cPassword;
	}

	public void setcPassword(String cPassword) {
		this.cPassword = cPassword;
	}

}
