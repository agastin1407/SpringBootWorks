package com.example.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.model.CustomerLoginDetails;
import com.example.model.FarmerLoginDetails;
import com.example.model.ProductDetails;
import com.example.service.ServiceClass;

@Controller
public class MainControllerClass {
	
	@Autowired
	ServiceClass service;
	
	@Autowired
	JdbcTemplate jdbc;
	
	@GetMapping("/f")
	public String navigateFarmerLogin() {
		System.out.println("hi");
		return "farmerLogin";
	}

	@GetMapping("/c")
	public String navigateCustomerLogin() {
		return "customerLogin";
	}
	
	@GetMapping("/fRegister")
	public String navigateFarmerRegister() {
		return "farmerRegister";
	}
	

	@GetMapping("/cRegister")
	public String navigateCustomerRegister() {
		return "customerRegister";
	}
	
	@PostMapping("/fLogin")
	public String fLoginAction(@RequestParam("fEmailId")String email, @RequestParam("fPassword")String password) {
		String query = "select * from flogin where fEmailId='" + email + "';";
		FarmerLoginDetails fd = jdbc.queryForObject(query, BeanPropertyRowMapper.newInstance(FarmerLoginDetails.class));
		if (fd.getfPassword().equalsIgnoreCase(password)) {
			return "FarmerFormFill";
		} else {
			return "invalidDetails";
		}
	}

	@PostMapping("/cLogin")
	public String cLoginAction(@RequestParam("cEmailId")String email, @RequestParam("cPassword")String password, ModelMap map ) {
		String query = "select * from clogin where cEmailId='" + email + "';";
		CustomerLoginDetails cd = jdbc.queryForObject(query, BeanPropertyRowMapper.newInstance(CustomerLoginDetails.class));
		if (cd.getcPassword().equalsIgnoreCase(password)) {
			List<ProductDetails> pd =service.showCart();
			map.addAttribute("pd", pd);
			return "productList";
		} else {
			return "invalidDetails";
		}
	}
	@PostMapping("/fregisterAction")
	public String udateFarmerRegisterAccount(@ModelAttribute("FDetails") FarmerLoginDetails fd) {
		service.createFarmerRegisterAoount(fd);
		return "farmerLogin";

	}
	@PostMapping("/cregisterAction")
	public String udateCustomerRegisterAccount(@ModelAttribute("CDetails") CustomerLoginDetails cd) {
		service.createCustomerRegisterAoount(cd);
		return "customerLogin";

	}
	
	@PostMapping("/FarmerFormAction")
	public String insertFarmerData(@ModelAttribute("productDetails") ProductDetails pd) {
		service.inseertProductDetails(pd);
		return "success";
	}
	
	@GetMapping("/addToCart")
	public String addToCart(@RequestParam("Id")int id,ModelMap map) {
		List<ProductDetails> pd = service.addToCart(id);
		map.addAttribute("pd", pd);
		return "productList";
		
	}
	
	@GetMapping("/cart")
	public String navigateCart(ModelMap map) {
		List<ProductDetails> pd = service.showNewCart();
		map.addAttribute("pd", pd);
		int sum = pd.stream().filter(o -> o.getPrice() > 10).mapToInt(o -> o.getPrice()).sum();
		map.addAttribute("sum", sum);
		return "cart";
	}
	
	@GetMapping("/remove")
	public String removeFromCart(@RequestParam("Id")int id,ModelMap map) {
		List<ProductDetails> pd = service.removeFromCart(id);
		map.addAttribute("pd", pd);
		return "cart";
	}
	
	@GetMapping("/pay")
	public String pay() {
		return "payform";		
	}
	
	@PostMapping("/PayAction")
	public String payAction(@RequestParam("name")String name,@RequestParam("cardno")String no,@RequestParam("cvv")String cvv,@RequestParam("date")String date,@RequestParam("amount")int amount) {
		service.payment(name,no,cvv,date,amount);
		service.dropCart();
		return "paid";
		
	}
	@GetMapping("/logout")
	public String logout() {
		service.dropCart();
		return "customerLogin";
	}
	
	
	

}
