package com.example.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.model.CustomerLoginDetails;
import com.example.model.PhramaLoginDetails;
import com.example.model.ProductDetails;
import com.example.service.ServiceClass;

@Controller
public class MainControllerClass {
	
	@Autowired
	ServiceClass service;
	
	@Autowired
	JdbcTemplate jdbc;
	
	@GetMapping("/p")
	public String navigatePharmaLogin() {
		return "pharmaLogin";
	}

	@GetMapping("/c")
	public String navigateCustomerLogin() {
		return "customerLogin";
	}
	
	@GetMapping("/pRegister")
	public String navigatePharmaRegister() {
		return "pharmaRegister";
	}
	

	@GetMapping("/cRegister")
	public String navigateCustomerRegister() {
		return "customerRegister";
	}
	
	@PostMapping("/pLogin")
	public String pharmaLoginAction(@RequestParam("pharmaEmailId")String email, @RequestParam("pharmaPassword")String password) {
		String query = "select * from pharmalogin where pharmaEmailId='" + email + "';";
		PhramaLoginDetails phd = jdbc.queryForObject(query, BeanPropertyRowMapper.newInstance(PhramaLoginDetails.class));
		if (phd.getPharmaPassword().equalsIgnoreCase(password)) {
			return "PharmaFormFill";
		} else {
			return "invalidDetails";
		}
	}

	@PostMapping("/cLogin")
	public String customerLoginAction(@RequestParam("customerEmailId")String email, @RequestParam("customerPassword")String password, ModelMap map ) {
		String query = "select * from customerlogin where customerEmailId='" + email + "';";
		CustomerLoginDetails cd = jdbc.queryForObject(query, BeanPropertyRowMapper.newInstance(CustomerLoginDetails.class));
		if (cd.getCustomerPassword().equalsIgnoreCase(password)) {
			List<ProductDetails> phd =service.showCart();
			map.addAttribute("phd", phd);
			return "productList";
		} else {
			return "invalidDetails";
		}
	}
	@PostMapping("/pregisterAction")
	public String udatePharmaRegisterAccount(@ModelAttribute("PDetails") PhramaLoginDetails pd) {
		service.createPharmaRegisterAoount(pd);
		return "pharmaLogin";

	}
	@PostMapping("/cregisterAction")
	public String udateCustomerRegisterAccount(@ModelAttribute("CDetails") CustomerLoginDetails cd) {
		service.createCustomerRegisterAoount(cd);
		return "customerLogin";

	}
	
	@PostMapping("/PharmaFormAction")
	public String insertPharmaData(@ModelAttribute("productDetails") ProductDetails pd) {
		service.insertProductDetails(pd);
		return "success";
	}
	
	@GetMapping("/addToCart")
	public String addToCart(@RequestParam("Id")int id,ModelMap map) {
		List<ProductDetails> phd = service.addToCart(id);
		map.addAttribute("phd", phd);
		return "productList";
		
	}
	
	@GetMapping("/cart")
	public String navigateCart(ModelMap map) {
		List<ProductDetails> pd = service.showNewCart();
		System.out.println(pd);
		map.addAttribute("pd", pd);
		int sum = pd.stream().filter(o -> o.getPrice() > 10).mapToInt(o -> o.getPrice()).sum();
		map.addAttribute("sum", sum);
		return "cart";
	}
	
	@GetMapping("/remove")
	public String removeFromCart(@RequestParam("Id")int id,ModelMap map) {
		List<ProductDetails> pd = service.removeFromCart(id);
		map.addAttribute("pd", pd);
		return "cart";
	}
	
	@GetMapping("/pay")
	public String pay() {
		return "payform";		
	}
	
	@PostMapping("/PayAction")
	public String payAction(@RequestParam("name")String name,@RequestParam("cardno")String no,@RequestParam("cvv")String cvv,@RequestParam("date")String date,@RequestParam("amount")int amount) {
		service.payment(name,no,cvv,date,amount);
		service.dropCart();
		return "paid";
		
	}
	@GetMapping("/logout")
	public String logout() {
		service.dropCart();
		return "customerLogin";
	}

}
