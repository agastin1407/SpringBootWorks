package com.example.service;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.stereotype.Service;

import com.example.model.CustomerLoginDetails;
import com.example.model.PhramaLoginDetails;
import com.example.model.ProductDetails;


@Service
public class ServiceClass {

	@Autowired
	JdbcTemplate jdbc;

	public void createPharmaRegisterAoount(PhramaLoginDetails pd) {
		PreparedStatementCreator obj = new PreparedStatementCreator() {

			@Override
			public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
				// TODO Auto-generated method stub
				PreparedStatement sql = con.prepareStatement("insert into pharmalogin values (?,?,?) ");
				sql.setString(1, pd.getPharmaName());
				sql.setString(2, pd.getPharmaEmailId());
				sql.setString(3, pd.getPharmaPassword());
				return sql;
			}
		};
		jdbc.update(obj);
	}

	public void createCustomerRegisterAoount(CustomerLoginDetails cd) {
		PreparedStatementCreator obj = new PreparedStatementCreator() {

			@Override
			public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
				// TODO Auto-generated method stub
				PreparedStatement sql = con.prepareStatement("insert into customerlogin values (?,?,?) ");
				sql.setString(1, cd.getCustomerName());
				sql.setString(2, cd.getCustomerEmailId());
				sql.setString(3, cd.getCustomerPassword());
				return sql;
			}
		};
		jdbc.update(obj);
	}

	public void insertProductDetails(ProductDetails pd) {
		PreparedStatementCreator obj = new PreparedStatementCreator() {

			@Override
			public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
				PreparedStatement sql = con.prepareStatement("insert into productDetails values (?,?,?,?,?,?,?,?,?) ");
				sql.setInt(1, pd.getpId());
				sql.setString(2, pd.getPharmaName());
				sql.setString(3, pd.getProductName());
				sql.setString(4, pd.getCategory());
				sql.setInt(5, pd.getDosage());
				sql.setInt(6, pd.getQuantity());
				sql.setInt(7, pd.getPrice());
				sql.setString(8, pd.getExpDate());
				sql.setString(9, pd.getContact());
				return sql;
			}
		};
		jdbc.update(obj);
	}

	public List<ProductDetails> showCart() {
		String sql="select * from productDetails;";
		List<ProductDetails> pd = jdbc.query(sql, BeanPropertyRowMapper.newInstance(ProductDetails.class));
		String query="create table cart( pId int, pharmaName varchar(50), productName varchar(100), category varchar(100),dosage int, quantity int, price int,expDate date,contact varchar(12));";
		jdbc.execute(query);
		return pd;
	}

	public List<ProductDetails> addToCart(int id) {
		String sql = "select * from productDetails where pId='" + id + "' ;";
		ProductDetails pd = jdbc.queryForObject(sql, BeanPropertyRowMapper.newInstance(ProductDetails.class));
		PreparedStatementCreator obj = new PreparedStatementCreator() {
			@Override
			public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
				PreparedStatement sql = con.prepareStatement("insert into cart values (?,?,?,?,?,?,?,?,?) ");
				sql.setInt(1, pd.getpId());
				sql.setString(2, pd.getPharmaName());
				sql.setString(3, pd.getProductName());
				sql.setString(4, pd.getCategory());
				sql.setInt(5, pd.getDosage());
				sql.setInt(6, pd.getQuantity());
				sql.setInt(7, pd.getPrice());
				sql.setString(8, pd.getExpDate());
				sql.setString(9, pd.getContact());
				return sql;
			}
		};
		jdbc.update(obj);
		String sql1="select * from productDetails;";
		List<ProductDetails> pd1 = jdbc.query(sql1, BeanPropertyRowMapper.newInstance(ProductDetails.class));
		return pd1;
	}

	public List<ProductDetails> removeFromCart(int id) {
		String sql= "delete from cart where pId='"+id+ "';";
		jdbc.execute(sql);
		String sql1="select * from cart ;";
		List<ProductDetails> pdc = jdbc.query(sql1, BeanPropertyRowMapper.newInstance(ProductDetails.class));
		return pdc;
	}

	public void dropCart() {
		String sql="drop table cart;";
		jdbc.execute(sql);
		
	}

	public void payment(String name, String no, String cvv, String date, int amount) {
		PreparedStatementCreator obj = new PreparedStatementCreator() {

			@Override
			public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
				PreparedStatement sql = con.prepareStatement("insert into paymentDetails values (?,?,?,?,?) ");
				sql.setString(1, name);
				sql.setString(2, no);
				sql.setString(3, cvv);
				sql.setString(4, date);
				sql.setInt(5, amount);
				return sql;
			}
		};
		jdbc.update(obj);

	}

	public List<ProductDetails> showNewCart() {
		String sql="select * from cart ;";
		List<ProductDetails> pdc = jdbc.query(sql, BeanPropertyRowMapper.newInstance(ProductDetails.class));
		return pdc;
	}

}
