package com.example.model;

public class PhramaLoginDetails {
	private String pharmaName;
	private String pharmaEmailId;
	private String pharmaPassword;
	public String getPharmaName() {
		return pharmaName;
	}
	public void setPharmaName(String pharmaName) {
		this.pharmaName = pharmaName;
	}
	public String getPharmaEmailId() {
		return pharmaEmailId;
	}
	public void setPharmaEmailId(String pharmaEmailId) {
		this.pharmaEmailId = pharmaEmailId;
	}
	public String getPharmaPassword() {
		return pharmaPassword;
	}
	public void setPharmaPassword(String pharmaPassword) {
		this.pharmaPassword = pharmaPassword;
	}
	@Override
	public String toString() {
		return "PhramaLoginDetails [pharmaName=" + pharmaName + ", pharmaEmailId=" + pharmaEmailId + ", pharmaPassword="
				+ pharmaPassword + "]";
	}

}
