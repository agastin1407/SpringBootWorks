package com.example.model;

public class CustomerLoginDetails {
	private String customerName;
	private String customerEmailId;
	private String customerPassword;
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerEmailId() {
		return customerEmailId;
	}
	public void setCustomerEmailId(String customerEmailId) {
		this.customerEmailId = customerEmailId;
	}
	public String getCustomerPassword() {
		return customerPassword;
	}
	public void setCustomerPassword(String customerPassword) {
		this.customerPassword = customerPassword;
	}
	@Override
	public String toString() {
		return "CustomerLoginDetails [customerName=" + customerName + ", customerEmailId=" + customerEmailId
				+ ", customerPassword=" + customerPassword + "]";
	}

	
}
