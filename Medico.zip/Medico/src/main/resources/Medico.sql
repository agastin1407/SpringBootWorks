drop database Medico;
create database Medico;
use Medico;
create table pharmalogin(
pharmaName varchar(50),
pharmaEmailId varchar(50),
pharmaPassword varchar(50)
);
create table customerlogin(
customerName varchar(50),
customerEmailId varchar(50),
customerPassword varchar(50)
);
drop table productDetails;
create table productDetails(
pId int auto_increment NOT NULL primary key,
pharmaName varchar(50),
productName varchar(100),
category varchar(100),
dosage int,
quantity int,
price int,
expDate varchar(20),
contact varchar(12)
);
drop table paymentDetails;
create table paymentDetails(
payeeName varchar(100),
cardNumber varchar(20),
cvv varchar(10),
expiryDate varchar(20),
amount int
);
delete from productDetails;
select * from paymentDetails;
select * from productDetails;
select * from pharmalogin;
select * from customerlogin;
show tables;
drop table cart;
select * from cart;