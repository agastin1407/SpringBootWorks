package com.cognizant.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.demo.Repository.CountryRepository;
import com.cognizant.demo.model.Country;

@Service
public class CountryService {

	@Autowired
	CountryRepository cRepo;

	@Transactional
	public List<Country> getAllCountries() {
		return (List<Country>) cRepo.findAll();
	}

}
