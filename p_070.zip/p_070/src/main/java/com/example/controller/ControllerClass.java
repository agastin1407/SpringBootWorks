package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.model.AdminLogin;
import com.example.model.CustomerLogin;
import com.example.model.FlightInfo;
import com.example.service.ServiceClass;

@Controller
public class ControllerClass {
	
	@Autowired
	ServiceClass sc;
	
	@Autowired
	JdbcTemplate jdbc;
	
	@GetMapping("/")
	public String initialization() {
		return "login";
	}

	@GetMapping("/adminReg")
	public String iniateAdminRegister() {
		return "adminReg";
	}

	@GetMapping("/custReg")
	public String initiateCustomerRegister() {
		return "custReg";
	}

	@PostMapping("/adminlogin")
	public String adminLogin(@RequestParam("adminEmail") String email, @RequestParam("adminPassword") String password,ModelMap map) {
		String query = "select * from admin where adminEmail='" + email + "';";
		AdminLogin admin = jdbc.queryForObject(query,
				BeanPropertyRowMapper.newInstance(AdminLogin.class));
		if (admin.getAdminPassword().equalsIgnoreCase(password)) {
			List<FlightInfo> fi=sc.createEditList();
			map.addAttribute("fi",fi);
			return "EditDetails";
		} else {
			return "invalidLogin";
		}
	}
	
	@PostMapping("/editInfo")
	public String updateFlightInfo(@ModelAttribute("editFlightInfo")FlightInfo fii,ModelMap map) {
		sc.editFlightInfo(fii);
		List<FlightInfo> fi=sc.createEditList();
		map.addAttribute("fi",fi);
		return "EditDetails";
		
	}
	
	@PostMapping("/customerlogin")
	public String customerLogin(@RequestParam("customerEmail") String email,
			@RequestParam("customerPassword") String password, ModelMap map) {
		String query = "select * from customer where customerEmail='" + email + "';";
		CustomerLogin customer = jdbc.queryForObject(query,
				BeanPropertyRowMapper.newInstance(CustomerLogin.class));
		if (customer.getCustomerPassword().equalsIgnoreCase(password)) {
			return "CustomerPage";
		} else {
			return "invalidLogin";
		}
	}

	@PostMapping("/adminRegister")
	public String createAdminAccount(@ModelAttribute("adminDeatils") AdminLogin ad,ModelMap map) {
		try {
		sc.createAdminAcount(ad);
		}
		catch(Exception e) {
			map.put("e","USER ALREADY EXISTS");
			return "adminReg";
		}
		return "login";
	}

	@PostMapping("/customerRegister")
	public String createCustomerAccount(@ModelAttribute("customerDetails") CustomerLogin cd,ModelMap map) {
		try {
		sc.createCustomerAcount(cd);
		}
		catch(Exception error) {
			map.put("error", "USER ALREADY EXISTS");
			return"custReg";
		}
		return "login";

	}
	
	@PostMapping("/searchaction")
	public String getCustomerResults(@RequestParam("departureCity")String departureCity,@RequestParam("arrivalCity")String arrivalCity,@RequestParam("departureDate")String departureDate,@RequestParam("classType")String classType,ModelMap map) {
		List<FlightInfo> fi = sc.findCustomerResult(departureCity,arrivalCity,departureDate,classType); 
		map.addAttribute("fi", fi);
		return "flightResult";
	}
	
	@GetMapping("/bookFlightTicket")
	public String ticketBookingSuccess() {
		return "success";
	}
	
	@GetMapping("/cancelFlight")
	public String cancelFlights(ModelMap map) {
		List<FlightInfo> fii=sc.createEditList();
		map.addAttribute("fii",fii);
		//System.out.println(fii);
		return "cancelPage";
	}

	@GetMapping("/cancel")
	public String CancelFlightsAction(@RequestParam("id")int id,ModelMap map){
		sc.cancelFlight(id);
		List<FlightInfo> fi=sc.createEditList();
		map.addAttribute("fi",fi);
		return "EditDetails";		
	}
}
