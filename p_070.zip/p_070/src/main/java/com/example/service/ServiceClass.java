package com.example.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.stereotype.Service;

import com.example.model.AdminLogin;
import com.example.model.CustomerLogin;
import com.example.model.FlightInfo;

@Service
public class ServiceClass {

	@Autowired
	JdbcTemplate jdbc;

	public void createAdminAcount(AdminLogin ad) {
		PreparedStatementCreator obj = new PreparedStatementCreator() {

			@Override
			public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
				// TODO Auto-generated method stub
				PreparedStatement sql = con.prepareStatement("insert into admin values (?,?,?) ");
				sql.setString(1, ad.getAdminName());
				sql.setString(2, ad.getAdminEmail());
				sql.setString(3, ad.getAdminPassword());
				return sql;
			}
		};
		jdbc.update(obj);
	}

	public void createCustomerAcount(CustomerLogin cd) {
		PreparedStatementCreator obj = new PreparedStatementCreator() {

			@Override
			public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
				PreparedStatement sql = con.prepareStatement("insert into customer values (?,?,?) ");
				sql.setString(1, cd.getCustomerName());
				sql.setString(2, cd.getCustomerEmail());
				sql.setString(3, cd.getCustomerPassword());
				return sql;
			}
		};
		jdbc.update(obj);
	}

	public List<FlightInfo> createEditList() {
		String sql = "select * from FlightInfo;";
		List<FlightInfo> fi = jdbc.query(sql, BeanPropertyRowMapper.newInstance(FlightInfo.class));
		return fi;
	}

	public List<FlightInfo> findCustomerResult(String departureCity, String arrivalCity, String departureDate,
			String classType) {
		String sql = "select * from FlightInfo WHERE departureCity='" + departureCity + "' AND arrivalCity='"
				+ arrivalCity + "' AND departureDate='" + departureDate + "' AND classType='" + classType + "';";
		List<FlightInfo> fi = jdbc.query(sql, BeanPropertyRowMapper.newInstance(FlightInfo.class));
		return fi;
	}

	public void editFlightInfo(FlightInfo fii) {
		jdbc.update("update FlightInfo set flightNumber='" + fii.getFlightNumber() + "', airlinesName='"
				+ fii.getAirlinesName() + "', departureCity='" + fii.getDepartureCity() + "',arrivalCity='"
				+ fii.getArrivalCity() + "',departureDate='" + fii.getDepartureDate() + "',departureTime='"
				+ fii.getDepartureTime() + "', arrivalTime='" + fii.getArrivalTime() + "',duration="
				+ fii.getDuration() + ",classType='" + fii.getClassType() + "',price=" + fii.getPrice()
				+ " WHERE id='" + fii.getId() + "' ;");
	}

	public void cancelFlight(int id) {
		String sql=" delete from FlightInfo WHERE id='"+id+"';";
		jdbc.execute(sql);
	}
}


