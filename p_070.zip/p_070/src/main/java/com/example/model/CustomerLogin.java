package com.example.model;

public class CustomerLogin {
	
	private String customerName;
	private String customerEmail;
	private String customerPassword;
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerEmail() {
		return customerEmail;
	}
	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}
	public String getCustomerPassword() {
		return customerPassword;
	}
	public void setCustomerPassword(String customerPassord) {
		this.customerPassword = customerPassord;
	}
	@Override
	public String toString() {
		return "CustomerLogin [customerName=" + customerName + ", customerEmail=" + customerEmail + ", customerPassword="
				+ customerPassword + "]";
	}
	
	

}
