create database p_070;
use p_070;
create table admin(
adminName varchar (30),
adminEmail varchar (50) unique NOT NULL,
adminPassword varchar(30)
);
create table customer(
customerName varchar(30),
customerEmail varchar(50) unique NOT NULL,
customerPassword varchar(30)
);
drop table FlightInfo;
create table FlightInfo(
id int NOT NULL primary key,
flightNumber varchar(10),
airlinesName varchar(30),
departureCity varchar(30),
arrivalCity varchar(30),
departureDate varchar(15),
departureTime varchar(30),
arrivalTime varchar(30),
duration float,
classType varchar(15),
price float
);
insert into FlightInfo values (0,"SG-3309","Spicejet","Chennai","Bengaluru","2020-09-01","19:40:00","21:10:00",90,"Economy",2345);
insert into FlightInfo values (1,"6E-6897","IndiGo","Chennai","Bengaluru","2020-09-02","06:00:00","06:50:00",50,"Economy",2358);
insert into FlightInfo values (2,"AI-535","Air India","New Delhi","Kolkata","2020-09-01","16:20:00","18:30:00",130,"Business",22858),
(3,"UK-737","Vistara","New Delhi","Kolkata","2020-09-02","14:20:00","16:25:00",125,"Economy",7986);
insert into FlightInfo values (4,"UK-877","Vistara","Mumbai","Hyderabad","2020-09-03","10:40:00","12:10:00",90,"Economy",2944),
(5,"SG-8185","Spicejet","Pune","Bengaluru","2020-09-02","11:30:00","13:00:00",90,"Premium Economy",4699),
(6,"AI-651","Air India","Visakhapatnam","Mumbai","2020-09-04","14:30:00","16:30:00",120,"Business",23129),
(7,"UK-884","Vistara","Thiruvananthapuram","New Delhi","2020-09-03","11:30:00","16:30:00",300,"Business",20876),
(8,"UK-825","Vistara","Mumbai","Chennai","2020-09-02","09:45:00","11:50:00",125,"First Class",44568),
(9,"SG-3302","Spicejet","Bengaluru","Chennai","2020-09-04","07:40:00","08:45:00",65,"Premium Economy",3694),
(10,"6E-2135","IndiGo","Kochi","Patna","2020-09-01","23:10:00","05:35:00",385,"Economy",7558),
(11,"6E-6231","IndiGo","Lucknow","Patna","2020-09-02","20:30:00","21:45:00",75,"First Class",35675),
(12,"G8-503","Go Air","Hyderbad","Chennai","2020-09-03","17:10:00","18:30:00",80,"Business",22335),
(13,"I5-302","AirAsia","Bengaluru","Chennai","2020-09-04","08:30:00","09:20:00",50,"Economy",2493),
(14,"6E-6012","IndiGo","Bengaluru","Chennai","2020-09-02","16:15:00","17.:15:00",60,"Business",20590);

select * from admin;
select * from customer;
select * from FlightInfo;
