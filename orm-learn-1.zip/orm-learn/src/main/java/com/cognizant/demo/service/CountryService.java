package com.cognizant.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.demo.Repository.CountryRepository;
import com.cognizant.demo.model.Country;

@Service
@Transactional
public class CountryService {

	@Autowired
	CountryRepository cRepo;

	public List<Country> getAllCountries() {
		return (List<Country>) cRepo.findAll();
	}

	public Country findCountryByCode(String countryCode) throws CountryNotFoundException {
		Optional<Country> result = cRepo.findById(countryCode);
		//System.out.println(result);
		Country country = result.get();
		//System.out.println(country);
		return country;
	}

	public void addCountry(Country country) {
		cRepo.save(country);
	}
	
	public void deleteCountry(String countryCode) {
		cRepo.deleteById(countryCode);
	}
	
	public void updateCountry(String name, String countryCode) throws CountryNotFoundException {
		Country c = findCountryByCode(countryCode);
		c.setName(name);
		cRepo.save(c);
		
		
	}
}
