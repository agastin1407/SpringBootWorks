package com.cognizant.truyum.dao;

public class CartEmptyException extends Exception {
	private String message;
	public CartEmptyException(String message) {
		super(message);
		this.message = message;
	}

}
