package com.cognizant.truyum.controller;

import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cognizant.truyum.dao.MenuItemDao;
import com.cognizant.truyum.model.MenuItem;
import com.cognizant.truyum.service.MenuItemService;

public class MenuItemController {

	private static final Logger LOGGER = LoggerFactory.getLogger(MenuItemController.class);

	@Autowired
	private MenuItemService menuItemService;

	@RequestMapping(value = "/show-menu-item-list-admin", method = RequestMethod.GET)
	public String showMenuItemListAdmin(ModelMap model) {
		LOGGER.info("Start");
		List menuItemListAdmin = menuItemService.getMenuItemListAdmin();
		model.addAttribute("getMenuItemListAdmin", menuItemListAdmin);
		LOGGER.info("End");
		return "menu-item-list-admin";
	}

	@RequestMapping(value = "/show-menu-list-customer", method = RequestMethod.GET)
	public String showMenuItemListCustomer(ModelMap model) {
		LOGGER.info("Start");
		List menuItemListCustomer = menuItemService.getMenuItemListCustomer();
		model.addAttribute("getMenuItemListAdmin", menuItemListCustomer);
		LOGGER.info("End");
		return "menu-item-list-customer";
	}

	@RequestMapping(value = "/show-edit-menu-item", method = RequestMethod.GET)
	public String showEditMenuItem(@RequestParam long menuItemId, ModelMap model) {
		LOGGER.info("Start");
		MenuItem menuItem = menuItemService.getMenuItem(menuItemId);
		model.addAttribute("MenuItem", menuItem);
		LOGGER.info("End");
		return "edit-menu-item";

	}

	@SuppressWarnings("null")
	@RequestMapping(value = "/edit-menu-item", method = RequestMethod.POST)
	public String editMenuItem(@Valid MenuItem menuItem, BindingResult bindingResult) {
		LOGGER.info("Start");
		if (bindingResult.hasErrors()) {
			return "edit-menu-item";
		}
		MenuItemDao menuItemDao = null;
		menuItemDao.modifyMenuItem(menuItem);
		LOGGER.info("End");
		return "edit-menu-item-status";
	}

}
