package com.cognizant.truyumspringmvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TruyumSpringMvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(TruyumSpringMvcApplication.class, args);
	}

}
